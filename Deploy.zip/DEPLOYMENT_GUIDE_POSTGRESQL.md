# 🚀 Smart Recipe Generator - Complete Deployment Guide (PostgreSQL)

This comprehensive guide covers deploying your Smart Recipe Generator application (Next.js + PostgreSQL/Prisma + Gemini AI) to a new server.

## 📋 1. Complete File List

### Essential Files and Directories to Copy:

```
smart-recipe-generator/
├── src/                          # All source code
├── prisma/                       # Database schema and migrations
│   ├── schema.prisma            # Database schema definition
│   └── migrations/              # Database migration files (if any)
├── public/                       # Static assets
├── package.json                  # Dependencies and scripts
├── package-lock.json            # Exact dependency versions
├── next.config.mjs              # Next.js configuration
├── tailwind.config.js           # Tailwind CSS configuration
├── postcss.config.js            # PostCSS configuration
├── tsconfig.json                # TypeScript configuration
├── .env.local.example           # Environment template
├── .gitignore                   # Git ignore rules
└── README.md                    # Documentation
```

### Files to EXCLUDE (will be regenerated):
- `.next/` (build output)
- `node_modules/` (dependencies)
- `.env.local` (contains secrets)
- `*.log` (log files)

## 🛠️ 2. Environment Setup

### System Requirements:
- **OS**: Ubuntu 20.04+ / CentOS 8+ / macOS / Windows
- **RAM**: Minimum 2GB, recommended 4GB+
- **Storage**: At least 2GB free space
- **Network**: Internet access for dependencies and AI API

### Software Dependencies:

#### A. Install Node.js (v18.0+)
```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# CentOS/RHEL
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# macOS (using Homebrew)
brew install node

# Verify installation
node --version  # Should be v18.0+
npm --version
```

#### B. Install PostgreSQL (v12+)
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install postgresql postgresql-contrib

# CentOS/RHEL
sudo yum install postgresql-server postgresql-contrib
sudo postgresql-setup initdb

# macOS
brew install postgresql
brew services start postgresql

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Verify installation
sudo -u postgres psql -c "SELECT version();"
```

#### C. Install PM2 (Production Process Manager)
```bash
sudo npm install -g pm2
```

## 🗄️ 3. Database Migration

### Step 1: Create PostgreSQL Database and User
```bash
# Switch to postgres user
sudo -u postgres psql

# In PostgreSQL shell:
CREATE DATABASE smart_recipe_generator;
CREATE USER recipe_user WITH ENCRYPTED PASSWORD 'recipe_password_123';
GRANT ALL PRIVILEGES ON DATABASE smart_recipe_generator TO recipe_user;
ALTER USER recipe_user CREATEDB;
\q
```

### Step 2: Export Data from Current Server (if needed)
```bash
# On current server - export PostgreSQL data
pg_dump -h localhost -U recipe_user -d smart_recipe_generator > backup.sql

# Transfer backup.sql to new server
scp backup.sql user@new-server:/path/to/backup.sql
```

### Step 3: Import Data to New Server
```bash
# On new server - import data
psql -h localhost -U recipe_user -d smart_recipe_generator < backup.sql
```

## ⚙️ 4. Configuration Steps

### Step 1: Create Environment Files
```bash
# Create .env file for Prisma
cat > .env << 'EOF'
DATABASE_URL="postgresql://recipe_user:recipe_password_123@localhost:5432/smart_recipe_generator?schema=public"
EOF

# Create .env.local for application
cat > .env.local << 'EOF'
# Next.js Configuration - UPDATE THESE FOR YOUR SERVER
NEXT_PUBLIC_API_BASE_URL=http://YOUR_SERVER_IP:3002
NEXTAUTH_URL=http://YOUR_SERVER_IP:3002
NEXTAUTH_SECRET=GENERATE_NEW_SECRET_HERE

# Local Authentication - GENERATE NEW SECRETS
JWT_SECRET=GENERATE_NEW_JWT_SECRET_HERE
BCRYPT_ROUNDS=12

# PostgreSQL Configuration
DATABASE_URL="postgresql://recipe_user:recipe_password_123@localhost:5432/smart_recipe_generator?schema=public"

# AI API Configuration (keep same)
LM_STUDIO_BASE_URL=https://hahahagame-gemini-play.deno.dev
LM_STUDIO_API_KEY=AIzaSyBzW2lNRzFaZ16T7SEr5HlYfQQVogpMf4U

# API Request Limit
API_REQUEST_LIMIT=100

# Storage Paths
IMAGES_STORAGE_PATH=./public/images/recipes
AUDIO_STORAGE_PATH=./public/audio/recipes
EOF
```

### Step 2: Generate Secure Secrets
```bash
# Generate JWT Secret
JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")

# Generate NextAuth Secret  
NEXTAUTH_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")

# Update .env.local with generated secrets
sed -i "s/GENERATE_NEW_JWT_SECRET_HERE/$JWT_SECRET/" .env.local
sed -i "s/GENERATE_NEW_SECRET_HERE/$NEXTAUTH_SECRET/" .env.local

# Replace YOUR_SERVER_IP with actual IP
read -p "Enter your server IP address: " SERVER_IP
sed -i "s/YOUR_SERVER_IP/$SERVER_IP/g" .env.local
```

### Step 3: Configure Firewall (if needed)
```bash
# Ubuntu/Debian (UFW)
sudo ufw allow 3002/tcp
sudo ufw allow 22/tcp
sudo ufw enable

# CentOS/RHEL (firewalld)
sudo firewall-cmd --permanent --add-port=3002/tcp
sudo firewall-cmd --reload
```

## 🔨 5. Build and Deployment Process

### Step 1: Transfer Application Files
```bash
# Method 1: Using SCP
scp -r /path/to/smart-recipe-generator user@new-server:/home/user/

# Method 2: Using Git (recommended)
git clone https://github.com/yourusername/smart-recipe-generator.git
cd smart-recipe-generator
```

### Step 2: Install Dependencies
```bash
cd smart-recipe-generator
npm install
```

### Step 3: Setup Database Schema
```bash
# Generate Prisma client
npx prisma generate

# Apply database schema
npx prisma db push

# Verify schema
npx prisma db pull
```

### Step 4: Create Initial Admin User
```bash
# Create admin user script
cat > create-admin.js << 'EOF'
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

async function createAdmin() {
  const prisma = new PrismaClient();
  
  try {
    const hashedPassword = await bcrypt.hash('admin123', 12);
    
    const admin = await prisma.user.create({
      data: {
        email: 'admin@test.com',
        name: 'Test Admin',
        password: hashedPassword,
        role: 'admin',
        isActive: true,
        preferences: {},
        stats: {}
      }
    });
    
    console.log('✅ Admin user created:', admin.email);
  } catch (error) {
    console.error('❌ Error creating admin:', error);
  } finally {
    await prisma.$disconnect();
  }
}

createAdmin();
EOF

# Run admin creation
node create-admin.js
rm create-admin.js
```

### Step 5: Build Application
```bash
# Build for production
npm run build

# Test build
npm start &
sleep 5
curl http://localhost:3000/api/system/status
kill %1
```

### Step 6: Setup Production Process Manager
```bash
# Create PM2 ecosystem file
cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'smart-recipe-generator',
    script: 'npm',
    args: 'start',
    cwd: '/home/user/smart-recipe-generator',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3002
    }
  }]
};
EOF

# Start application with PM2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

## ✅ 6. Verification Steps

### Step 1: Basic Health Checks
```bash
# Check if application is running
pm2 status

# Check application logs
pm2 logs smart-recipe-generator

# Check database connection
psql -h localhost -U recipe_user -d smart_recipe_generator -c "SELECT COUNT(*) FROM users;"

# Check if port is listening
netstat -tlnp | grep :3002
```

### Step 2: API Endpoint Tests
```bash
# Test system status
curl http://localhost:3002/api/system/status

# Test authentication
curl -X POST http://localhost:3002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@test.com", "password": "admin123"}'

# Test recipe generation (with auth token from above)
curl -X POST http://localhost:3002/api/recipes/generate \
  -H "Content-Type: application/json" \
  -H "Cookie: auth-token=YOUR_TOKEN_HERE" \
  -d '{"ingredients": [{"name": "chicken", "quantity": "1 lb"}], "dietaryPreferences": ["High Protein"]}'
```

### Step 3: Frontend Functionality Tests
```bash
# Open in browser or use curl
curl -I http://YOUR_SERVER_IP:3002/

# Test main pages
curl -I http://YOUR_SERVER_IP:3002/generate
curl -I http://YOUR_SERVER_IP:3002/community
```

### Step 4: Database Verification
```bash
# Connect to database and verify tables
psql -h localhost -U recipe_user -d smart_recipe_generator

# In PostgreSQL shell:
\dt                    # List all tables
SELECT COUNT(*) FROM users;
SELECT COUNT(*) FROM recipes;
SELECT COUNT(*) FROM forumposts;
\q
```

## 🔧 Troubleshooting

### Common Issues and Solutions:

#### 1. Database Connection Failed
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check database exists
sudo -u postgres psql -l | grep smart_recipe

# Test connection
psql -h localhost -U recipe_user -d smart_recipe_generator -c "SELECT 1;"
```

#### 2. Application Won't Start
```bash
# Check logs
pm2 logs smart-recipe-generator

# Check environment variables
cat .env.local

# Restart application
pm2 restart smart-recipe-generator
```

#### 3. Port Access Issues
```bash
# Check if port is in use
sudo lsof -i :3002

# Check firewall
sudo ufw status
```

## 🎯 Quick Deployment Script

Save this as `deploy.sh` for automated deployment:

```bash
#!/bin/bash
set -e

echo "🚀 Smart Recipe Generator Deployment Script"

# Install dependencies
npm install

# Setup database
npx prisma generate
npx prisma db push

# Build application
npm run build

# Start with PM2
pm2 start ecosystem.config.js
pm2 save

echo "✅ Deployment complete!"
echo "🌐 Access your app at: http://$(curl -s ifconfig.me):3002"
```

## 📞 Support

If you encounter issues:
1. Check the logs: `pm2 logs smart-recipe-generator`
2. Verify environment variables in `.env.local`
3. Test database connection manually
4. Ensure all required ports are open
5. Check system resources (RAM, disk space)

Your Smart Recipe Generator should now be fully deployed and functional! 🍳✨
