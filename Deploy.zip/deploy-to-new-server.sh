#!/bin/bash

# Smart Recipe Generator - Automated Deployment Script
# This script automates the deployment process to a new server

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_step() {
    echo -e "${YELLOW}➤ $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "This script should not be run as root"
   exit 1
fi

print_header "🚀 Smart Recipe Generator Deployment"

# Get server information
read -p "Enter your server IP address (for external access): " SERVER_IP
read -p "Enter database password for recipe_user [recipe_password_123]: " DB_PASSWORD
DB_PASSWORD=${DB_PASSWORD:-recipe_password_123}

print_header "📦 PHASE 1: SYSTEM DEPENDENCIES"

print_step "1. Updating system packages..."
sudo apt update && sudo apt upgrade -y
print_success "System updated"

print_step "2. Installing Node.js 18..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
    print_success "Node.js installed"
else
    NODE_VERSION=$(node --version)
    print_success "Node.js already installed: $NODE_VERSION"
fi

print_step "3. Installing PostgreSQL..."
if ! command -v psql &> /dev/null; then
    sudo apt install -y postgresql postgresql-contrib
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
    print_success "PostgreSQL installed and started"
else
    print_success "PostgreSQL already installed"
fi

print_step "4. Installing PM2 process manager..."
if ! command -v pm2 &> /dev/null; then
    sudo npm install -g pm2
    print_success "PM2 installed"
else
    print_success "PM2 already installed"
fi

print_header "🗄️  PHASE 2: DATABASE SETUP"

print_step "5. Creating PostgreSQL database and user..."
sudo -u postgres psql << EOF
CREATE DATABASE smart_recipe_generator;
CREATE USER recipe_user WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE smart_recipe_generator TO recipe_user;
ALTER USER recipe_user CREATEDB;
\q
EOF
print_success "Database and user created"

print_header "📁 PHASE 3: APPLICATION SETUP"

print_step "6. Installing application dependencies..."
if [ ! -f "package.json" ]; then
    print_error "package.json not found. Make sure you're in the application directory."
    exit 1
fi

npm install
print_success "Dependencies installed"

print_step "7. Generating secure secrets..."
JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")
NEXTAUTH_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
print_success "Secrets generated"

print_step "8. Creating environment configuration..."

# Create .env file for Prisma
cat > .env << EOF
DATABASE_URL="postgresql://recipe_user:$DB_PASSWORD@localhost:5432/smart_recipe_generator?schema=public"
EOF

# Create .env.local for application
cat > .env.local << EOF
# Next.js Configuration
NEXT_PUBLIC_API_BASE_URL=http://$SERVER_IP:3002
NEXTAUTH_URL=http://$SERVER_IP:3002
NEXTAUTH_SECRET=$NEXTAUTH_SECRET

# Local Authentication
JWT_SECRET=$JWT_SECRET
BCRYPT_ROUNDS=12

# PostgreSQL Configuration
DATABASE_URL="postgresql://recipe_user:$DB_PASSWORD@localhost:5432/smart_recipe_generator?schema=public"

# AI API Configuration
LM_STUDIO_BASE_URL=https://hahahagame-gemini-play.deno.dev
LM_STUDIO_API_KEY=AIzaSyBzW2lNRzFaZ16T7SEr5HlYfQQVogpMf4U

# API Request Limit
API_REQUEST_LIMIT=100

# Storage Paths
IMAGES_STORAGE_PATH=./public/images/recipes
AUDIO_STORAGE_PATH=./public/audio/recipes
EOF

print_success "Environment files created"

print_step "9. Setting up database schema..."
npx prisma generate
npx prisma db push
print_success "Database schema applied"

print_step "10. Creating admin user..."
cat > create-admin.js << 'EOF'
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

async function createAdmin() {
  const prisma = new PrismaClient();
  
  try {
    // Check if admin already exists
    const existingAdmin = await prisma.user.findUnique({
      where: { email: 'admin@test.com' }
    });
    
    if (existingAdmin) {
      console.log('Admin user already exists');
      return;
    }
    
    const hashedPassword = await bcrypt.hash('admin123', 12);
    
    const admin = await prisma.user.create({
      data: {
        email: 'admin@test.com',
        name: 'Test Admin',
        password: hashedPassword,
        role: 'admin',
        isActive: true,
        preferences: {},
        stats: {
          recipesGenerated: 0,
          recipesSaved: 0,
          recipesShared: 0,
          lastActiveAt: new Date()
        }
      }
    });
    
    console.log('✅ Admin user created:', admin.email);
  } catch (error) {
    console.error('❌ Error creating admin:', error);
  } finally {
    await prisma.$disconnect();
  }
}

createAdmin();
EOF

node create-admin.js
rm create-admin.js
print_success "Admin user created"

print_header "🔨 PHASE 4: BUILD AND DEPLOYMENT"

print_step "11. Building application for production..."
npm run build
print_success "Application built"

print_step "12. Creating PM2 configuration..."
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'smart-recipe-generator',
    script: 'npm',
    args: 'start',
    cwd: '$(pwd)',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3002
    }
  }]
};
EOF
print_success "PM2 configuration created"

print_step "13. Starting application with PM2..."
pm2 start ecosystem.config.js
pm2 save
pm2 startup
print_success "Application started"

print_header "🔥 PHASE 5: FIREWALL CONFIGURATION"

print_step "14. Configuring firewall..."
if command -v ufw &> /dev/null; then
    sudo ufw allow 3002/tcp
    sudo ufw allow 22/tcp
    sudo ufw --force enable
    print_success "UFW firewall configured"
elif command -v firewall-cmd &> /dev/null; then
    sudo firewall-cmd --permanent --add-port=3002/tcp
    sudo firewall-cmd --permanent --add-port=22/tcp
    sudo firewall-cmd --reload
    print_success "Firewalld configured"
else
    print_warning "No firewall detected. Make sure port 3002 is accessible."
fi

print_header "✅ PHASE 6: VERIFICATION"

print_step "15. Running health checks..."

# Wait for application to start
sleep 10

# Check PM2 status
if pm2 status | grep -q "smart-recipe-generator"; then
    print_success "PM2 process running"
else
    print_error "PM2 process not running"
fi

# Check if port is listening
if netstat -tlnp | grep -q ":3002"; then
    print_success "Application listening on port 3002"
else
    print_error "Application not listening on port 3002"
fi

# Test API endpoint
if curl -s http://localhost:3002/api/system/status | grep -q "success"; then
    print_success "API endpoints responding"
else
    print_warning "API endpoints may not be responding correctly"
fi

# Test database connection
if psql -h localhost -U recipe_user -d smart_recipe_generator -c "SELECT COUNT(*) FROM users;" &> /dev/null; then
    print_success "Database connection working"
else
    print_error "Database connection failed"
fi

print_header "🎉 DEPLOYMENT COMPLETE!"

echo ""
echo "📋 Deployment Summary:"
echo "   ✅ System dependencies installed"
echo "   ✅ PostgreSQL database configured"
echo "   ✅ Application built and deployed"
echo "   ✅ PM2 process manager configured"
echo "   ✅ Firewall configured"
echo ""
echo "🌐 Access Information:"
echo "   External URL: http://$SERVER_IP:3002"
echo "   Local URL: http://localhost:3002"
echo ""
echo "🔑 Admin Credentials:"
echo "   Email: admin@test.com"
echo "   Password: admin123"
echo ""
echo "🗄️  Database Information:"
echo "   Host: localhost:5432"
echo "   Database: smart_recipe_generator"
echo "   User: recipe_user"
echo "   Password: $DB_PASSWORD"
echo ""
echo "🔧 Management Commands:"
echo "   View logs: pm2 logs smart-recipe-generator"
echo "   Restart app: pm2 restart smart-recipe-generator"
echo "   Stop app: pm2 stop smart-recipe-generator"
echo "   App status: pm2 status"
echo ""
echo "🧪 Test Your Deployment:"
echo "   1. Open: http://$SERVER_IP:3002"
echo "   2. Login with admin credentials"
echo "   3. Test recipe generation"
echo "   4. Test community forum"
echo ""
print_success "Your Smart Recipe Generator is now live! 🍳✨"
